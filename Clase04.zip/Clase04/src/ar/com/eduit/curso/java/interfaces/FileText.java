package ar.com.eduit.curso.java.interfaces;

import java.io.File;

public class FileText implements I_File {

    private File file;

    public FileText(File file) {
        this.file = file;
    }

    @Override
    public void setText(String text) {
        System.out.println("Escribiendo Archivo de texto");
    }

    @Override
    public String getText() {
        return "Archivo de texto!";
    }

}