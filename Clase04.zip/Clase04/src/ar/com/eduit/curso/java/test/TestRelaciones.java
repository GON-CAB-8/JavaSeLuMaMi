package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.ClienteEmpresa;
import ar.com.eduit.curso.java.entities.ClientePersona;
import ar.com.eduit.curso.java.entities.Cuenta;
import java.util.ArrayList;

public class TestRelaciones {
    public static void main(String[] args) {
        //punto de entrada del proyecto.
        
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1, "arg$");
        cuenta1.depositar(150000);
        cuenta1.depositar(60000);
        cuenta1.debitar(30000);
        System.out.println(cuenta1);
        
        System.out.println("-- clientePersona1 --");
        ClientePersona clientePersona1=new ClientePersona(1, "Juan Perez", 44, cuenta1);
        clientePersona1.getCuenta().depositar(10000);
        clientePersona1.comprar();
        System.out.println(clientePersona1);
        
        System.out.println("-- Matrimonio clienteAna clienteMatias --");
        ClientePersona clienteAna=new ClientePersona(2, "Ana", 30, new Cuenta(2,"arg$"));
        clienteAna.getCuenta().depositar(60000);
        clienteAna.comprar();
        
        ClientePersona clienteMatias=new ClientePersona(3, "Matias", 30, clienteAna.getCuenta());
        clienteMatias.getCuenta().debitar(20000);
        
        System.out.println(clienteAna);
        System.out.println(clienteMatias);
        
        System.out.println("-- clientePersona4 --");
        ClientePersona clientePersona4=new ClientePersona(4, "Nicolas", 24, 3, "arg$");
        clientePersona4.getCuenta().depositar(50000);
        System.out.println(clientePersona4);
        
        System.out.println("-- clienteEmpresa1 --");
        ClienteEmpresa clienteEmpresa1=new ClienteEmpresa(1, "Todo Limpio srl", "Lima 222");
        clienteEmpresa1.comprar();
        
        ArrayList<Cuenta> cuentas=clienteEmpresa1.getCuentas();
        
        cuentas.add(new Cuenta(10,"arg$"));                 // 0
        cuentas.add(new Cuenta(11,"Reales"));               // 1
        cuentas.add(new Cuenta(12,"U$S"));                  // 2
        
        cuentas.get(0).depositar(250000);
        cuentas.get(0).depositar(120000);
        cuentas.get(0).debitar(30000);
        cuentas.get(1).depositar(24000);
        cuentas.get(2).depositar(12000);
        
        System.out.println(clienteEmpresa1);
        
        
        
    }
}