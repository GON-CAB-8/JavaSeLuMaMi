package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.entities.Direccion;
import ar.com.eduit.curso.java.entities.Persona;
import ar.com.eduit.curso.java.entities.Vendedor;

public class TestHerencia {
    public static void main(String[] args) {
        System.out.println("-- dir1 --");
        Direccion dir1=new Direccion("Belgrano", 42, null, null, "Moron");
        System.out.println(dir1);
        
        System.out.println("-- dir2 --");
        Direccion dir2=new Direccion("Lima", 111, "1", "a");
        System.out.println(dir2);
        
        //System.out.println("-- persona1 --");
        //Persona persona1=new Persona("Juan Gomez", 40, dir2);
        //persona1.saludar();
        //System.out.println(persona1);
        
        System.out.println("-- vendedor1 --");
        Vendedor vendedor1=new Vendedor(1, 450000, "Eliana Correa", 29, dir1);
        vendedor1.saludar();
        System.out.println(vendedor1);
        
        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente(1, new Cuenta(20,"arg$"), "Mario Gomez", 60, dir2);
        cliente1.getCuenta().depositar(400000);
        cliente1.saludar();
        System.out.println(cliente1);
        
        //Poliformismo Poliformismo
        Persona p1=new Vendedor(2, 90000, "Ana Gallardo", 30, dir2);
        Persona p2=new Cliente(2, new Cuenta(30,"arg$"), "Sebastian Presta", 30, dir2);
        
        p1.saludar();
        p2.saludar();
        
        Object o1=p1;
        Vendedor v1=(Vendedor)p1;
        
        Vendedor v2=(p1 instanceof Vendedor)?(Vendedor)p1:null;
        
        
        switch(o1.getClass().getSimpleName()){
            case "Vendedor" : System.out.println("Es un vendedor"); break;
            case "Cliente"  : System.out.println("Es un cliente");  break;
            case "String"   : System.out.println("Es un String");   break;
            default         : System.out.println("Clase no conocida");
        }
        
        System.out.println(p1.getClass());
        System.out.println(p1.getClass().getName());
        System.out.println(p1.getClass().getSimpleName());
        System.out.println(p1.getClass().getSuperclass().getName());
        System.out.println(p1.getClass().getSuperclass().getSuperclass().getName());
        System.out.println(p1.getClass().getSuperclass().getSuperclass().getSuperclass());
        System.out.println("".getClass().getName());
        System.out.println("".getClass().getSuperclass().getName());
        
        
        
    }
}