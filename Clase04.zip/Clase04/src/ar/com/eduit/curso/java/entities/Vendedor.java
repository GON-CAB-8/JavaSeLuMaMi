package ar.com.eduit.curso.java.entities;

public class Vendedor extends Persona{
    private int nroLegago;
    private double sueldoBasico;

    public Vendedor(int nroLegago, double sueldoBasico, String nombre, int edad, Direccion direccion) {
        //Llama al constructor de la clase padre.
        super(nombre, edad, direccion);
        this.nroLegago = nroLegago;
        this.sueldoBasico = sueldoBasico;
    }
    
    @Override
    public void saludar(){
        System.out.println("Hola soy un Vendedor!");
    }

    @Override
    public String toString() {
        return "Vendedor{" + "nroLegago=" + nroLegago + ", sueldoBasico=" + sueldoBasico + '}'+super.toString();
        /*
                this.toString();            // llama al toString de la misma clase.         Junior
                super.toString();           // llama al toString de la clase padre.         Senior
        */
    }

    public int getNroLegago() {
        return nroLegago;
    }

    public double getSueldoBasico() {
        return sueldoBasico;
    }

}