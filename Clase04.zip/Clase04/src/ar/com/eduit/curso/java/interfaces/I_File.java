package ar.com.eduit.curso.java.interfaces;

public interface I_File {
    /*
        Las interfaces:
        
        - No tiene constructores ni atributos.
        - Solo pueden tener atributos final o static.
        - Todos sus miembros son publicos.
        - Todos los métodos son abstractos.
        - Una clase puede implementar muchas interfaces.
    */
    
    /**
     * La JavaDOC es heredada
     * @param text 
     */
    void setText(String text);
    
    String getText();
    
    //métodos default JDK 8 o superior.
    default void info(){
        System.out.println("Interface I_File");
    }
    
}