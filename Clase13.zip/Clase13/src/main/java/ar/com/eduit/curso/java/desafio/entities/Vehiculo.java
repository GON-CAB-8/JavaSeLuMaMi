package ar.com.eduit.curso.java.desafio.entities;

import java.text.DecimalFormat;

public abstract class Vehiculo implements Comparable<Vehiculo> {
    private String marca;
    private String modelo;
    private double precio;
    private final DecimalFormat df= new DecimalFormat("###,###,###.00");

    public Vehiculo(String marca, String modelo, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Marca: "+marca+" // Modelo: "+modelo+" // ";
    }

    @Override
    public int compareTo(Vehiculo para) {
        String thisAuto = this.getMarca()+","+this.getModelo();
        String paraAuto = para.getMarca()+","+para.getModelo();
        return thisAuto.compareTo(paraAuto);
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getPrecio() {
        return precio;
    }
    
    public String getPrecioFormat(){
        return " // Precio: $"+df.format(precio);
    }
}
