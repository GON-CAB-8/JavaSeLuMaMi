package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connectors.Connector;
import java.sql.Connection;
import java.sql.ResultSet;
import java.time.LocalTime;

public class TestConnector {
    public static void main(String[] args) {
        LocalTime ltInicio=LocalTime.now();
        try (Connection conn=Connector.getConnection()){
            ResultSet rs=conn.createStatement().executeQuery("select version()");
            if(rs.next())
                System.out.println(rs.getString(1));
            else
                System.out.println("No se pudo conectar");  
        } catch (Exception e) {
            System.out.println("No se pudo conectar");
            System.out.println(e);
        }
        LocalTime ltFinal=LocalTime.now();
        System.out.println("Tiempo de respuesta: "+
                ((double)(ltFinal.toNanoOfDay()-ltInicio.toNanoOfDay())/1000000000)
                +" segundos"); 
    }
}