package ar.com.eduit.curso.java.test;

import ar.org.centro8.curso.java.utils.files.FileText;
import ar.org.centro8.curso.java.utils.files.I_File;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.URL;
import java.util.List;

public class TestFiles {
    public static void main(String[] args) {
        I_File fText=new FileText("texto.txt");
        fText.setText("Curso de Java!\n");
        fText.appendText("Hoy es Martes!\n");
        fText.addLine("Lunes");
        fText.addLine("Martes");
        fText.addLine("Miércoles");
        fText.addLine("Jueves");
        fText.addLine("Viernes");
        fText.addLine("Sábado");
        fText.addLine("Domingo");
        fText.addLine("Lunes");
        fText.addLine("Martes");
        List<String>estaciones=List.of("Primavera", "Verano", "Otoño", "Invierno");
        fText.addLines(estaciones);
        
        //System.out.println(fText.getText());
        //fText.print();
        
        //fText.getAll().forEach(System.out::println);
        //fText.getLikeFilter("m").forEach(System.out::println);
        //fText.getSortedLines().forEach(System.out::println);
        //fText.getReversedSortedLines().forEach(System.out::println);
        //fText.getLinkedHashSet().forEach(System.out::println);
        //fText.getTreeSet().forEach(System.out::println);
        
        
        /*
        String text="";
        System.out.println(text+"\t"+text.hashCode());
        text+="h";
        System.out.println(text+"\t"+text.hashCode());
        text+="o";
        System.out.println(text+"\t"+text.hashCode());
        text+="l";
        System.out.println(text+"\t"+text.hashCode());
        text+="a";
        System.out.println(text+"\t"+text.hashCode());
        
        StringBuilder sb=new StringBuilder();
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        sb.append("h");
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        sb.append("o");
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        sb.append("l");
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        sb.append("a");
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        
        
        for(int a=1;a<=10000000;a++){
            //text+="x";
            sb.append("x");
        }
        */
        
        //System.out.println(getHtml("https://listado.mercadolibre.com.ar/carpa-coleman#D[A:carpa%20coleman]"));
        
    }
    
    public static String getHtml(String url){
        StringBuilder sb=new StringBuilder();
        int car;
        try (InputStreamReader in = new InputStreamReader(new URL(url).openStream()))
        {
            while((car=in.read())!=-1){
                sb.append((char)car);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return sb.toString();
    }
    
}
