package clase06;

import java.util.LinkedHashMap;
import java.util.Map;

public class EmpleadoAuto {
    private Map<Auto,Empleado>map=new LinkedHashMap();

    public Map<Auto,Empleado> getMap() {
        return map;
    }
  
}