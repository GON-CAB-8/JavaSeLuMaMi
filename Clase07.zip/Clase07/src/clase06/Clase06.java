package clase06;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

public class Clase06 {

    public static void main(String[] args) {
        // Vectores - Arrays
        Auto[] autos=new Auto[4];
        autos[0]=new Auto("Ford","Ka","Negro");
        autos[1]=new Auto("Fiat","Idea","Gris");
        autos[2]=new Auto("Renault","Kangoo","Verde");
        autos[3]=new Auto("Citroen","C4","Bordo");
        
        // Recorrido con indices
        //for(int a=0;a<autos.length;a++) System.out.println(autos[a]);
        
        // Recorrido forEach
        for(Auto a:autos) System.out.println(a);
        
        //Framework Collections
        
        //Interface List
        List list;
        list=new ArrayList();
        //list=new LinkedList();
        //list=new Vector();
        list.add(new Auto("Peugeot","3008","Gris"));        // 0
        list.add(new Auto("Honda","Civic","Gris"));         // 1
        list.add("Hola");                                   // 2
        list.add("Mundo");                                  // 3
        list.add(26);                                       // 4
        list.add(2,"Java");
        list.remove(4);
        
        //Copiar los autos del vector autos a list
        for(Auto a:autos) list.add(a);
        
        //Recorrido con indices
        System.out.println("****************************************************");
        //for(int a=0;a<list.size();a++) System.out.println(list.get(a));
        
        //Recorrido forEach
        //for(Object o:list) System.out.println(o);
        
        //Método default forEach JDK8
        //list.forEach(o->{
        //    System.out.println(o);
        //});
        
        //list.forEach(o->System.out.println(o));
        
        list.forEach(System.out::println);
        
        
        //Uso de Generics<> JDK 5 o sup.
        List<Auto>list2=new ArrayList();
        list2.add(new Auto("Toyota","Corolla","Blanco"));
        
        Auto a1=(Auto)list.get(0);
        Auto a2=list2.get(0);
        Auto a3=a1;
        
        //Copiar los autos de list a list2
        list.forEach(o->{
            if(o instanceof Auto) list2.add((Auto)o);
        });
        
        System.out.println("****************************************************");
        list2.forEach(System.out::println);
        
        // Interface Set
        
        Set<String>set;
        
        // Implementación HashSet: Es la más veloz, no garantiza el orden de los elementos.
        //set=new HashSet();
        
        // Implementación LinkedHashSet: Almacena elementos en una lista enlazada 
        //                                  por orden de ingreso.
        //set=new LinkedHashSet();
        
        // Implementación TreeSet:  Almacena elementos en un arbol, por orden natural
        set=new TreeSet();
        
        //app
        set.add("Lunes.");
        set.add("Martes.");
        set.add("Miércoles.");
        set.add("Jueves.");
        set.add("Lunes.");
        set.add("Martes.");
        set.add("Viernes.");
        set.add("Sábado.");
        set.add("Domingo.");
        System.out.println("****************************************************");
        set.forEach(System.out::println);
        
        Set<Auto>setAutos;
        
        //setAutos=new HashSet();
        //setAutos=new LinkedHashSet();
        setAutos=new TreeSet();  
        
        setAutos.add(new Auto("Chevrolet","Corsa","Negro"));
        setAutos.addAll(list2);
        setAutos.add(new Auto("Citroen","C4","Bordo"));
        setAutos.add(new Auto("Citroen","C3","Verde"));
        setAutos.add(new Auto("Citroen","C3","Gris"));
        setAutos.add(new Auto("Citroen","C3","Azul"));
        setAutos.add(new Auto("Citroen","C3","Bordo"));
        System.out.println("****************************************************");
        setAutos.forEach(a->System.out.println(a+"\t"+a.hashCode()));
        
        // Estructura Pila - Clase Stack - LIFO (Last In First Out)
        Stack<Auto>pilaAutos=new Stack();
        pilaAutos.push(new Auto("VW","Gol","Rojo"));
        // .push() apila un elemento en la pila
        pilaAutos.addAll(setAutos);
        System.out.println("****************************************************");
        pilaAutos.forEach(System.out::println);
        System.out.println("Longitud de pila: "+pilaAutos.size());
        System.out.println(pilaAutos.pop());
        while(!pilaAutos.isEmpty()){
            System.out.println(pilaAutos.pop());
            // .pop() desapila un elemento de la pila
        }
        System.out.println("Longitud de pila: "+pilaAutos.size());
        
        //Estructura Cola - Clase ArrayDeque - FIFO (First In First Out)
        ArrayDeque<Auto>colaAutos=new ArrayDeque();
        colaAutos.offer(new Auto("VW","Up","Blanco"));
        // .offer() encolar un elemento en la cola.
        colaAutos.addAll(setAutos);
        System.out.println("****************************************************");
        colaAutos.forEach(System.out::println);
        System.out.println("Longitud de Cola: "+colaAutos.size());
        //while(!colaAutos.isEmpty()){
        while(colaAutos.size()>3){
            System.out.println(colaAutos.poll());
            // .poll() desencola un elemento
        }        
        System.out.println("Longitud de Cola: "+colaAutos.size());
        
        
        //Interface Map
        //Representa un vector asociativo o diccionario
        
        Map<String,String>map;
        
        // Implementación HashMap: es la más veloz pero no garantiza el orden de los elementos
        //map=new HashMap();
        
        // Implementación Hashtable: es muy antigua (legacy o obsoleta), hace lo mismo que HashMap
        //map=new Hashtable();
        
        // Implementación LinkedHashSet: almacena elementos en una lista enlazada por orden de ingreso.
        //map=new LinkedHashMap();
        
        // Implementación TreeMap: almacena elementos en un arbol ordenados por llave.
        map=new TreeMap();
        
        //app
        map.put("lu", "lunes");
        //map.put("lun", "lunes");
        //map.put("lu", "x");
        map.put("ma", "martes");
        map.put("mi", "miércoles");
        map.put("ju", "jueves");
        map.put("vi", "viernes");
        map.put("sa", "sábado");
        map.put("do", "domingo");
        System.out.println(map.get("ju"));
        System.out.println("****************************************************");
        map.forEach((k,v)->System.out.println(k+" "+v));
        
        EmpleadoAuto ea=new EmpleadoAuto();
        Empleado e1=new Empleado("e1");
        Empleado e2=new Empleado("e2");
        Empleado e3=new Empleado("e3");
        Empleado e4=new Empleado("e4");
        Empleado e5=new Empleado("e5");
        
        ea.getMap().put(list2.get(0), e1);
        ea.getMap().put(list2.get(1), e2);
        ea.getMap().put(list2.get(2), e3);
        ea.getMap().put(list2.get(3), e1);
        ea.getMap().put(list2.get(4), e4);
        
        System.out.println("Quien tiene el auto list2[2]? "+ea.getMap().get(list2.get(2)));
        
        ea.getMap().forEach((a,e)->System.out.println(e+" "+a));
        
        // API STREAM JDK o sup.
        
        List<Persona>personas=new ArrayList();
        personas.add(new Persona("Laura","Casas",30));
        personas.add(new Persona("Diego","Vega",40));
        personas.add(new Persona("Romina","Corso",35));
        personas.add(new Persona("Matias","Lorenzo",26));
        personas.add(new Persona("Debora","Vargas",41));
        personas.add(new Persona("Celeste","Rivas",27));
        personas.add(new Persona("Debora","Rojas",37));
        personas.add(new Persona("Debbie","Morte",39));
        personas.add(new Persona(null,"Morte",39));
        personas.add(new Persona("Cristian","Molina",26));
        
        
        System.out.println("****************************************************");
        //select * from personas where nombre='debora';
        
        //for(Persona p:personas){
        //    if(p.getNombre().toLowerCase().equals("debora")) System.out.println(p);
        //}
        
        personas
                .stream()
                .filter(p->p.getNombre()!=null && p.getNombre().toLowerCase().equals("debora"))
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select * from personas where nombre like '%deb%';
        personas
                .stream()
                .filter(p->p.getNombre()!=null && p.getNombre().toLowerCase().contains("deb"))
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select * from personas where nombre like '%deb%' and apellido like '%ro%' ;
        personas
                .stream()
                .filter(p->p.getNombre()!=null   && p.getNombre().toLowerCase().contains("deb")
                        && p.getApellido()!=null && p.getApellido().toLowerCase().contains("ro"))
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select * from personas where edad>=30 ;
        personas
                .stream()
                .filter(p->p.getEdad()>=30)
                .forEach(System.out::println);
        
        
        System.out.println("****************************************************");
        //select * from personas where edad between 30 and 40 ;
            personas
                .stream()
                .filter(p->p.getEdad()>=30 && p.getEdad()<=40)
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select max(edad) from personas;
            int edadMaxima=personas
                    .stream()
                    .max(Comparator.comparingInt(Persona::getEdad))
                    .get()
                    .getEdad();
        System.out.println(edadMaxima);
        
        System.out.println("****************************************************");
        //select min(edad) from personas;
        int edadMinima=personas
                    .stream()
                    .min(Comparator.comparingInt(Persona::getEdad))
                    .get()
                    .getEdad();
        System.out.println(edadMinima);
        
        System.out.println("****************************************************");
        //select * from personas where edad=(select min(edad) from personas);
        personas
                .stream()
                .filter(p->p.getEdad()==edadMinima)
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select * from personas order by apellido;
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getApellido))
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select * from personas where edad>=30 order by apellido;
        personas
                .stream()
                .filter(p->p.getEdad()>=30)
                .sorted(Comparator.comparing(Persona::getApellido))
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //orden natural
        personas
                .stream()
                .sorted()
                .forEach(System.out::println);
        
    }

}
