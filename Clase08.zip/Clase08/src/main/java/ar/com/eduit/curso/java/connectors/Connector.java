package ar.com.eduit.curso.java.connectors;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connector {

    //MySQL
    //private static String driver="org.mariadb.jdbc.Driver";
    //private static String vendor="mariadb";
    //private static String server="localhost";
    //private static String port="3306";
    //private static String bd="colegio";
    //private static String user="root";
    //private static String pass="";
    //private static String params="?serverTimezone=UTC";
    
    //Postgresql
    private static String driver="org.postgresql.Driver";
    private static String vendor="postgresql";
    private static String server="tuffi.db.elephantsql.com";
    private static String port="5432";
    private static String bd="dyeymnsa";
    private static String user="dyeymnsa";
    private static String pass="go7Wrgl4IYc-hnV8aGLDpjdqmXOAWNPr";
    private static String params="";
    
    //URL
    private static String url="jdbc:"+vendor+"://"+server+":"+port+"/"+bd+params;
    
    private static Connection conn=null;
    
    private Connector(){}
    
    public synchronized static Connection getConnection(){
        try{
            if(conn==null || conn.isClosed()){
                Class.forName(driver);
                conn=DriverManager.getConnection(url,user,pass);
            }
        }catch(Exception e){
            System.out.println(e);
        }
        return conn;
    }
}