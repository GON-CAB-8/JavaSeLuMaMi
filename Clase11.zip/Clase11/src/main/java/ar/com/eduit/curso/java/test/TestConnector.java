package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connectors.Connector;
import java.sql.ResultSet;
import java.time.LocalTime;

public class TestConnector {
    public static void main(String[] args) {
        double inicio=LocalTime.now().getNano()*0.0000000001;
        System.out.println(LocalTime.now());
        try (ResultSet rs=Connector
                .getConnection()
                .createStatement()
                .executeQuery("select version()")){
            if(rs.next()){
                System.out.println("Se conecto a "+rs.getString(1));
            }else{
                System.out.println("No se pudo conectar a la BD!");
            }
        } catch (Exception e) {
            System.out.println("No se pudo conectar a la BD!");
            System.out.println(e);
        }
        double fin=LocalTime.now().getNano()*0.0000000001;
        System.out.println("Tiempo de conexión "+(fin-inicio));
        System.out.println(LocalTime.now());
    }
}