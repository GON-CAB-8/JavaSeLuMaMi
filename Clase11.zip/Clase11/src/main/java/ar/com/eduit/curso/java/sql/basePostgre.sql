-- Base de datos PostgreSQL
select version();
drop table if exists alumnos;
drop table if exists cursos;

create table cursos(
    id serial primary key,
    titulo varchar(20) not null,
    profesor varchar(20),
    dia varchar(20),
    turno varchar(20)
);

create table alumnos(
    id serial primary key,
    nombre varchar(20) not null,
    apellido varchar(20) not null,
    edad int,
    idCurso int
);

alter table alumnos
    add constraint FK_alumnos_cursos
    foreign key(idCurso)
    references cursos(id);

alter table alumnos
    add constraint CH_alumnos_edad
    check(edad >=18 and edad<=120);

select * from cursos;