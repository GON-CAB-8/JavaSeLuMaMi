package ar.com.eduit.curso.java.entities;

public class ClientePersona {
    private int nro;
    private String nombre;
    private int edad;
    private Cuenta cuenta;
    
    //Un cliente puede ser creado sin una cuenta.
    //public ClientePersona(int nro, String nombre, int edad){
    //    this.nro = nro;
    //    this.nombre = nombre;
    //    this.edad = edad;
    //}

    //Un cliente siempre tiene una cuenta, un cliente se crea con una cuenta.
    //Una cuenta puede ser compartida por más de un cliente.
    public ClientePersona(int nro, String nombre, int edad, Cuenta cuenta) {
        this.nro = nro;
        this.nombre = nombre;
        this.edad = edad;
        this.cuenta = cuenta;
    }
    
    //Un cliente siempre tiene una cuenta, un cliente se crea con una cuenta.
    //Una cuenta solo pertenece a un cliente y solo uno, la cuenta propiedad del cliente.
    public ClientePersona(int nro, String nombre, int edad, int nroCuenta, String moneda) {
        this.nro = nro;
        this.nombre = nombre;
        this.edad = edad;
        this.cuenta = new Cuenta(nroCuenta,moneda);
    }

    public void comprar(){
        System.out.println("El cliente realiza una compra!");
    }
    
    @Override
    public String toString() {
        return "ClientePersona{" + "nro=" + nro + ", nombre=" + nombre + ", edad=" + edad + ", cuenta=" + cuenta + '}';
    }

    public int getNro() {
        return nro;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public Cuenta getCuenta() {
        return cuenta;
    }
    
    
}