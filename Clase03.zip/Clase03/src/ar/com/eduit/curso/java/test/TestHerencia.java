package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Direccion;

public class TestHerencia {
    public static void main(String[] args) {
        System.out.println("-- dir1 --");
        Direccion dir1=new Direccion("Belgrano", 42, null, null, "Moron");
        System.out.println(dir1);
        
        System.out.println("-- dir2 --");
        Direccion dir2=new Direccion("Lima", 111, "1", "a");
        System.out.println(dir2);
    }
}