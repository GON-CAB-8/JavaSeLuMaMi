package clase05;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Clase05 {

    public static void main(String[] args) {
        //System.out.println(10/1);
        //System.out.println("Esta sentencia no se ejecuta!!");

        /*
            Estructura Try - Catch - Finally
        
            try{                                    //bloque obligatorio
                - Colocar aquí las sentencias que pueden lanzar una Exception (Error).
                - Estas sentencias tienen más costo de hardware.
                - Si se puede ejecutan todas las sentencias de este bloque.
                - Si ocurre una Exception, se corta el control de este bloque del programa,
                    y pasa el control al bloque catch.
            } catch(Exception e){                   //bloque obligatorio
                - Este bloque se ejecuta en caso de existir Exception en el bloque try.
                - Se recibe como parametro un objeto de la clase Exception.
            } finally {                             //bloque opcional
                - Este bloque se ejecuta siempre.
                - Las variables creadas en bloque try o bloque catch estan fuera de scope(alcance).
            }
        
            - Estas sentencias, tambien se ejecutan siempre.
            - El programa termina normalmente.
            
         */
 /*
        try{
            System.out.println(10/1);
            System.out.println("Esta sentencia no se ejecuta.");
        }catch(Exception e){
            System.out.println("Ocurrio un error!");
            System.out.println(e);
        }finally{
            System.out.println("El programa termina normalmente!");
        }
         */
        //System.out.println("Hola");
        try {
            //GeneradorException.generar();
            GeneradorException.generar("26");
            GeneradorException.generar(false);
            GeneradorException.generar("Hola", 2);
            //FileReader in=new FileReader("texto.txt");
        } catch (Exception e) {
            System.out.println(e);
        }

        //GeneradorException.generar("38x");
        //int x=Integer.parseInt("26x");
        // Captura personalizada de Exception
        try {
            //GeneradorException.generar("hola",20);
            FileReader in = new FileReader("texto.txt");
            in.read();
            in.close();
        } catch (ArithmeticException e) {
            System.out.println("División / 0");
        } catch (NumberFormatException e) {
            System.out.println("Formato de número incorrecto!");
        } catch (NullPointerException e) {
            System.out.println("Puntero Nulo!");
            //} catch (ArrayIndexOutOfBoundsException e)  { System.out.println("Indice Fuera de Rango!");
            //} catch (StringIndexOutOfBoundsException e) { System.out.println("Indice Fuera de Rango!");
            //} catch (ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e) { System.out.println("Indice Fuera de Rango!");
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Indice Fuera de Rango!");
        } catch (FileNotFoundException e) {
            System.out.println("Archivo No Encontrado!");
        } catch (IOException e) {
            System.out.println("Error I/O");
        } catch (Exception e) {
            System.out.println("Ocurrio un error no esperado!");
        }

        //Uso de Exceptions para validar reglas de negocio.
        Vuelo v1 = new Vuelo("aer1234", 100);

        try {
            v1.venderPasajes(40);
            v1.venderPasajes(40);
            v1.venderPasajes(30);
        } catch (NoHayMasPasajesException ex) {
            System.out.println(ex);
        }

        //Uso de try with resources jdk 7
        try(FileReader in= new FileReader("texto.txt")) {
            in.read(); 
        } catch (Exception e) {
            System.out.println(e);
        }
        
        
        
        // NO HACER ESTO!!!
            FileReader in=null; 
            try {
                in = new FileReader("texto.txt");                // abre conexión a archivo
                in.read();                                      // lectura file
                in.close();                                     // cierra el archivo
            } catch (Exception e) {
                System.out.println(e);
                if(in!=null){
                    try{
                        in.close();
                    }catch(Exception ex){
                        System.out.println(ex);
                    }
                }
            }


    }

}
