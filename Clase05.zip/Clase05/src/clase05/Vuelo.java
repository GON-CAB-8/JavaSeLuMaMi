package clase05;

public class Vuelo {
    private String nombre;
    private int cantidadPasajesDisponibles;

    public Vuelo(String nombre, int cantidadPasajes) {
        this.nombre = nombre;
        this.cantidadPasajesDisponibles = cantidadPasajes;
    }

    public synchronized void venderPasajes(int cantidadPasajesPedida) throws NoHayMasPasajesException{
        if(cantidadPasajesDisponibles<cantidadPasajesPedida) 
            throw new NoHayMasPasajesException(nombre, cantidadPasajesDisponibles, cantidadPasajesPedida);
        cantidadPasajesDisponibles-=cantidadPasajesPedida;
    }
    
    @Override
    public String toString() {
        return "Vuelo{" + "nombre=" + nombre + ", cantidadPasajes=" + cantidadPasajesDisponibles + '}';
    }

    public String getNombre() {
        return nombre;
    }

    public int getCantidadPasajes() {
        return cantidadPasajesDisponibles;
    }

}