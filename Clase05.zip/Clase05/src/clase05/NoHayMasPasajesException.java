package clase05;

public class NoHayMasPasajesException extends Exception{
    private final String nombreVuelo;
    private final int cantidadPasajesDisponibles;
    private final int cantidadPasajesPedidas;

    public NoHayMasPasajesException(String nombreVuelo, int cantidadPasajesDisponibles, int cantidadPasajesPedidas) {
        this.nombreVuelo = nombreVuelo;
        this.cantidadPasajesDisponibles = cantidadPasajesDisponibles;
        this.cantidadPasajesPedidas = cantidadPasajesPedidas;
    }

    @Override
    public String toString() {
        return getMessage();
    }

    @Override
    public String getMessage() {
        return "El vuelo "+nombreVuelo+" no tiene "+cantidadPasajesPedidas+" pasajes, solo tiene "+
                cantidadPasajesDisponibles+" pasajes!";
    }

    public String getNombreVuelo() {
        return nombreVuelo;
    }

    public int getCantidadPasajesDisponibles() {
        return cantidadPasajesDisponibles;
    }

    public int getCantidadPasajesPedidas() {
        return cantidadPasajesPedidas;
    }
   
}