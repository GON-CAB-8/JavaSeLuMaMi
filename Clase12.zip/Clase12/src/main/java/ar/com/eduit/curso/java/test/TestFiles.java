package ar.com.eduit.curso.java.test;

import ar.org.centro8.curso.java.utils.files.FileText;
import ar.org.centro8.curso.java.utils.files.I_File;

public class TestFiles {
    public static void main(String[] args) {
        I_File fText=new FileText("texto.txt");
        fText.setText("Curso de Java!\n");
    }
}
