package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Alumno;
import ar.com.eduit.curso.java.entities.Curso;
import ar.com.eduit.curso.java.enums.Dia;
import ar.com.eduit.curso.java.enums.Turno;
import ar.com.eduit.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.com.eduit.curso.java.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.AlumnoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.CursoRepository;

public class TestRepository {
    public static void main(String[] args) {
        I_CursoRepository cr=new CursoRepository(Connector.getConnection());
        Curso curso=new Curso("Jarrones","Sotelo",Dia.LUNES,Turno.MAÑANA);
        cr.save(curso);
        System.out.println(curso);
        
        //cr.remove(cr.getById(7));
        
        //curso=cr.getById(6);
        //curso.setDia(Dia.MARTES);
        //cr.update(curso);
        
        System.out.println("****************************************************");
        cr.getAll().forEach(System.out::println);
        //cr.getLikeTitulo("Ja").forEach(System.out::println);
        //cr.getLikeTituloProfesor("ja", "os").forEach(System.out::println);
        
        System.out.println("****************************************************");
        I_AlumnoRepository ar=new AlumnoRepository(Connector.getConnection());
        Alumno alumno=new Alumno("Nicolas", "Leon", 24, 1);
        ar.save(alumno);
        System.out.println(alumno);
        
        
    }
}
