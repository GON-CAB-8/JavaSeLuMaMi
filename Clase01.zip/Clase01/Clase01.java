/**
 * Clase Principal del proyecto Clase01
 */
public class Clase01{
	/**
	 * Punto de entrada del proyecto
	 * El parametro String[] args, es un vector con los argumentos que se ingresan desde consola.
	 */
	public static void main(String[] args){
		/*
			Curso: Java Standard Web Programming 11.X
			Días: Lunes, Martes, Miércoles 10:00 a 13:00 hs.
			Profe: Carlos Rios	carlos.rios@educacionit.com
			Materiales: alumni.educacionit.com
					user: email
					pass: dni
			github: https://github.com/crios2020/JavaSeLuMaMi
			
			JDK		Java Development Kit
			Oracle - OpenJDK Oracle - IBM - REDHAT - Amazon - (Adopt J9)Eclipse
			
			Versiones LTS:	Long Term Support	8 años.
			
			Versión				Liberado				Fin de Soporte
			JDK 8	LTS			Marzo 2014				Marzo 2022
			JDK 9				Septiembre 2017			Marzo 2018
			JDK 10				Marzo 2018				Septiembre 2018
			JDK 11 LTS			Septiembre 2018			Septiembre 2026
			JDK 12				Marzo 2019				Septiembre 2019
			JDK 13				Septiembre 2019			Marzo 2020
			JDK 14				Marzo 2020				Septiembre 2020
			JDK	15				Septiembre 2020			Marzo 2021
			JDK 16				Marzo 2021				Septiembre 2021
			JDK 17 LTS			Sepetiembre 2021		Septiembre 2029
			
			IDE:	Integrated Development Enviroment
			
			Eclipse - IntelliJ - Netbeans - Spring Tools Suite - JDeveloper
		*/ 
		
		//Comentarios de una linea
		/* Bloque de Comentarios */
		
		/**
		 * Comentario es un comentario Java DOC.
		 * El Java DOC debe colocarse delante de la declaración de clase o atributo o método
		 * Este comentario es Visible desde fuera del binario.
		 */ 
		
		System.out.println("Hola Mundo");
		
		//Tipo de datos
		
		//Tipo de datos Enteros
		
		//Tipo de datos boolean					1 byte
		boolean bo=true;			//1
		System.out.println(bo);
		bo=false;					//0
		System.out.println(bo);
		
		//Tipo de datos byte					1 byte		-128 a 127
		byte by=-100;
		System.out.println(by);			
		
		//Tipo de datos short					2 bytes
		short sh=32000;	
		System.out.println(sh);
		
		//Tipo de datos int						4 bytes
		int in=2000000000;	
		System.out.println(in);
		
		
		//Tipo de datos long					8 bytes
		long lo=3000000000L;	
		System.out.println(lo);
		
		//Tipo de datos char					2 bytes
		char ch=65;
		ch='f';
		System.out.println(ch);
		
		
		//Tipo de datos Punto Flotante
		//Tipo de datos float 32 bits
		float fl=4.55f;
		System.out.println(fl);
		
		//Tipo de datos double 64 bits
		double dl=4.55;
		System.out.println(dl);
		
		fl=10;
		dl=10;
		
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		fl=100;
		dl=100;
		
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		//clase BigDecimal
		
		//clase String
		String st="Hola";
		System.out.println(st);
		
		/*
				JDK 9 o inf			String st="Hola";			private final char[] value;		8 bytes
				
				JDK 10 o sup		String st="Hola";			private final byte[] value;		4 bytes
		
		*/
		
		//Tipo de datos var		JDK 9 o sup.
		var var1 = 2;				//int	
		//var = "Hola"; //Error
		var var2 = true;			//boolean
		var var3 = '2';				//char
		var var4 = 2L;				//long
		var var5 = "2";				//String
		var var6 = 2.75;			//double
		var var7 = 2.75d;			//double
		var var8 = 2.75f;			//float
		var8++;
		
		final double PI=3.14;
		//PI++;
		
		System.out.println("Longitud args:"+args.length);
		for(int a=0;a<args.length;a++) System.out.println(args[a]);
	}
}
