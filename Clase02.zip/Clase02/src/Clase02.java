import javax.swing.JOptionPane;
public class Clase02 {
    public static void main(String[] args) {
        // Clase02
        System.out.println("Hola Mundo!!");
        //JOptionPane.showMessageDialog(null, "Hola Mundo!!");
        
        /*
        
        Programación Orientada a Objetos
        
        Clases: Las clases son plantillas que representan ideal del mundo real.
                Se encuentran como sustantivos. (Auto, Cliente, Articulo)
        
        Clases en Java: Las clases son objetos de la clase java.lang.Class
        
        Atributos:  Los atributos describen a una clase, son variables contenidas dentro de una clase.
                Tienen un tipo de datos definido. Las clases definen atributos y los objetos complentan
                el estado de los atributos. 
                Los atributos tienen una inicialización automatica. (Las variables no se inicializan)
        
        Atributos en Java: Los atributos son objetos de la clases java.lang.reflect.Field.
        
        Métodos: Los métodos son acciones que realiza la clase. Se detectan como verbos.
                Tiene parametros de Entrada y Salida.
        
        Métodos en Java: Los métodos son objetos de la clases java.lang.reflect.Method
        
        
        Objetos: Son situaciones o instancia en particular de una clase. Tienen estado propio.
        
        Sobrecarga de Métodos: Es la presencia de métodos con el mismo nombre, dentro de una clase.
                Pero debe ser distinta la firma de parametros de entrada.
        
        Métodos Constructores:  Los constructores inicializan objetos. se los invoca con la palabra new.
                No tiene devolución de valor. Tienen como nombre el mismo nombre que la clase.
                Pueden tener parametros de entrada y se pueden sobrecargar.
                Si la clase no tiene constructor Java agrega un constructor vacio al compilar.
        
        */
        
        System.out.println("-- auto1 --");
        Auto auto1=new Auto();              // new Auto() constructor de la clase Auto
        auto1.marca="Fiat";
        auto1.modelo="Idea";
        auto1.color="Gris";
        auto1.acelerar();           //10
        auto1.acelerar();           //20
        auto1.acelerar();           //30
        auto1.frenar();             //20
        auto1.acelerar(15);         //35
        
        
        
        System.out.println(auto1.marca+" "+auto1.modelo+" "+auto1.color+" "+auto1.velocidad);
        
        //int x;
        //System.out.println(x);
        //Error las variables deben ser inicializadas
        
        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="Ford";
        auto2.modelo="Ka";
        auto2.color="Rojo";
        for(int a=0;a<=38;a++) auto2.acelerar();
        System.out.println(auto2.marca+" "+auto2.modelo+" "+auto2.color+" "+auto2.velocidad);
        
        System.out.println("-- auto3 --");
        Auto auto3 = new Auto("VW", "UP", "Blanco");
        
        //Método toString()
        System.out.println(auto3.toString());
        System.out.println(auto3.toString(true));
        System.out.println(auto3.toString(false));
        System.out.println(auto3);
  
        
        System.out.println("-- empleado1 --");
        Empleado empleado1 = new Empleado(1, "Javier", "Larrosa", 45, 20000);
        //empleado1.sueldoBasico=9000000;
        empleado1.setSueldoBasico(9000000);
        System.out.println(empleado1);
        
        /* 
        Operadores de visibilidad
        
        Operador                Alcance
        default (Omitido)       Permite ver el miembro de clase desde la misma clase 
                                o clases del mismo paquete.
        public                  Permite ver desde la misma clase y desde clases de cualquier 
                                paquete.
        private                 Permite ver desde la misma clase.
        protected               Permite ver desde la misma clase, desde clases hijas o
                                desde clases del mismo paquete.
        
        
        */
        
        
    }
}