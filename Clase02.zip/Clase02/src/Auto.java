//Declaración de clase
public class Auto {
    
    // Atributos
    String marca;
    String modelo;
    String color;
    int velocidad;
    
    /**
     * Este método fue deprecado por Carlos Ríos el 10/05/2021,
     * por resultar inseguro.
     * Usar en su reemplazo Auto(String marca, String modelo, String color)
     * @deprecated
     */
    @Deprecated
    Auto(){
        //constructor vacio
    }    
    
    Auto(String marca, String modelo, String color){
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
    }
    
    // Métodos
    void acelerar(){                                            //acelerar
        velocidad+=10;
        if(velocidad>=100) velocidad=100;
    }
    
    // Métodos sobrecargados
    void acelerar(int kilometros){                              //acelerarInt
        velocidad+=kilometros;
        if(velocidad>=100) velocidad=100;
    }
    
    //void acelerar(int x){}                                      //acelerarInt
    
    void acelerar(String x){}                                   //acelerarString
    
    void acelerar(int kilometros,boolean nitro){}               //acelerarIntBoolean
    
    void frenar(){
        velocidad-=10;
    }
    
    @Override
    public String toString(){
        return marca+", "+modelo+", "+color+", "+velocidad;
    }
    
    String toString(boolean x){
        if(x){
            return super.toString();
        }else{
            return marca+", "+modelo+", "+color+", "+velocidad;
        }
    }
    
}//end class Auto